// Main Game Engine, Lighting, Input Loops & Interaction for NovaCraft
(function(global) {
    // Zero-Crash Safeguard: Prevent uncaught errors from freezing the game loop
    window.addEventListener('error', function(e) {
        console.warn('NovaCraft Safe Guard Error:', e.message);
        e.preventDefault();
    });
    window.addEventListener('unhandledrejection', function(e) {
        console.warn('NovaCraft Safe Guard Rejection:', e.reason);
        e.preventDefault();
    });

    class Game {
        constructor() {
            this.container = document.getElementById('game-container');
            this.showDebug = false;
            this.timeOfDay = 0.22; // 0.22 = bright morning (~8:30 AM), 0.25 = noon, 0.5 = sunset, 0.75 = midnight
            this.daySpeed = 0.000833; // 20 minutes per full day-night cycle (Minecraft Vanilla authentic)

            this.input = {
                keys: {},
                mouseButtons: {},
                spaceJustPressed: false,
                sprint: false
            };

            this.lastTime = performance.now();
            this.lastForwardPressTime = 0;
            this.lastClickTime = 0;
            this.fpsFrames = 0;
            this.fpsTime = 0;
            this.currentFPS = 60;
            this.gameStarted = false;
            this.pointerLockAcquired = false;

            this.initThree();
            this.initComponents();
            this.setupInputs();
            this.initHandMesh();

            // Auto-save every 30 seconds
            setInterval(() => this.saveManager.saveWorld(), 30000);

            // Load existing save or generate fresh
            const hasSave = this.saveManager.loadWorld();
            this.world.updateChunksAround(this.player.x, this.player.z, 2);
            const surfaceY = this.world.getHighestSolidY(Math.floor(this.player.x), Math.floor(this.player.z));
            if (!hasSave || this.player.y < surfaceY - 1.0 || this.player.y < 3.0) {
                this.player.y = surfaceY + 1.8;
                this.player.velocity.set(0, 0, 0);
            }

            this.animate();
        }

        initThree() {
            this.scene = new THREE.Scene();
            this.scene.background = new THREE.Color(0x78a7ff);
            this.scene.fog = new THREE.FogExp2(0x78a7ff, 0.015);

            this.camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 500);
            this.renderer = new THREE.WebGLRenderer({ antialias: false, powerPreference: 'high-performance' });
            this.renderer.setSize(window.innerWidth, window.innerHeight);
            this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
            this.container.appendChild(this.renderer.domElement);

            // Lighting
            this.ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
            this.scene.add(this.ambientLight);

            this.sunLight = new THREE.DirectionalLight(0xffffff, 0.9);
            this.sunLight.position.set(50, 100, 50);
            this.scene.add(this.sunLight);

            // Celestial Sun & Moon
            const sunGeo = new THREE.BoxGeometry(10, 10, 1);
            const sunMat = new THREE.MeshBasicMaterial({ color: 0xffffee });
            this.sunMesh = new THREE.Mesh(sunGeo, sunMat);
            this.scene.add(this.sunMesh);

            const moonGeo = new THREE.BoxGeometry(8, 8, 1);
            const moonMat = new THREE.MeshBasicMaterial({ color: 0xddddff });
            this.moonMesh = new THREE.Mesh(moonGeo, moonMat);
            this.scene.add(this.moonMesh);

            // Block selection wireframe box
            const wireGeo = new THREE.BoxGeometry(1.004, 1.004, 1.004);
            const wireMat = new THREE.MeshBasicMaterial({ color: 0x000000, wireframe: true });
            this.highlightBox = new THREE.Mesh(wireGeo, wireMat);
            this.highlightBox.visible = false;
            this.scene.add(this.highlightBox);

            // Realistic Minecraft Breaking / Crack Overlay Box
            const crackGeo = new THREE.BoxGeometry(1.006, 1.006, 1.006);
            this.crackMaterial = new THREE.MeshBasicMaterial({
                transparent: true,
                opacity: 0.85,
                depthWrite: false
            });
            this.crackBox = new THREE.Mesh(crackGeo, this.crackMaterial);
            this.crackBox.visible = false;
            this.scene.add(this.crackBox);

            // Authentic Minecraft Procedural Clouds
            this.cloudsGroup = new THREE.Group();
            const cloudMat = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.65 });
            const cloudGeo = new THREE.BoxGeometry(24, 4, 16);
            for (let cx = -4; cx <= 4; cx++) {
                for (let cz = -4; cz <= 4; cz++) {
                    if ((cx * 3 + cz * 7) % 3 === 0) {
                        const cloudPiece = new THREE.Mesh(cloudGeo, cloudMat);
                        cloudPiece.position.set(cx * 40, 56, cz * 40);
                        this.cloudsGroup.add(cloudPiece);
                    }
                }
            }
            this.scene.add(this.cloudsGroup);

            window.addEventListener('resize', () => {
                this.camera.aspect = window.innerWidth / window.innerHeight;
                this.camera.updateProjectionMatrix();
                this.renderer.setSize(window.innerWidth, window.innerHeight);
            });
        }

        initComponents() {
            this.atlas = new TextureAtlas();
            this.sound = new SoundEngine();
            this.world = new World(this.scene, this.atlas);
            this.physics = new Physics(this.world);
            this.player = new Player(this.camera, this.world, this.physics, this.sound);
            this.itemManager = new ItemManager(this.scene, this.world, this.sound);
            this.mobManager = new MobManager(this.scene, this.world, this.sound, this.itemManager);
            this.inventory = new Inventory();
            this.ui = new UIManager(this, this.inventory, this.player);
            this.saveManager = new SaveManager(this);

            // Bind atlas texture to crack material
            this.crackMaterial.map = this.atlas.getTexture();
        }

        initHandMesh() {
            // Authentic Minecraft first-person arm & held item model attached to camera
            this.handGroup = new THREE.Group();
            this.handGroup.position.set(0.36, -0.32, -0.48);
            this.currentHandItemKey = null;
            this.heldItemMesh = null;
            this.updateHandMesh(null);

            this.camera.add(this.handGroup);
            this.scene.add(this.camera);
        }

        updateHandMesh(itemKey) {
            if (this.currentHandItemKey === itemKey && this.heldItemMesh) return;
            this.currentHandItemKey = itemKey;

            // Clear previous model
            while (this.handGroup.children.length > 0) {
                this.handGroup.remove(this.handGroup.children[0]);
            }

            const itemDef = itemKey ? window.ITEMS[itemKey] : null;

            // Master Arm Rig (Steve's arm is ALWAYS rendered!)
            const armRig = new THREE.Group();

            // 1. Steve's Sleeve (Teal/Cyan)
            const sleeveMat = new THREE.MeshLambertMaterial({ color: 0x009a9a });
            const sleeve = new THREE.Mesh(new THREE.BoxGeometry(0.13, 0.26, 0.13), sleeveMat);
            sleeve.position.set(0, -0.13, 0);
            armRig.add(sleeve);

            // 2. Steve's Hand / Fist (Skin tone)
            const skinMat = new THREE.MeshLambertMaterial({ color: 0xcc8855 });
            const hand = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.16, 0.12), skinMat);
            hand.position.set(0, 0.08, 0);
            armRig.add(hand);

            // 3. Held Item attached to Hand
            if (itemDef?.blockId) {
                // Miniature 3D Voxel Block in hand
                const blockGeo = new THREE.BoxGeometry(0.22, 0.22, 0.22);
                this.atlas.applyBlockUVs(blockGeo, itemDef.blockId);
                const blockMat = new THREE.MeshLambertMaterial({
                    map: this.atlas.getTexture(),
                    transparent: true
                });
                const blockMesh = new THREE.Mesh(blockGeo, blockMat);
                blockMesh.position.set(0, 0.22, -0.06);
                blockMesh.rotation.set(0.3, 0.6, 0.1);
                armRig.add(blockMesh);
            } else if (itemKey === 'flint_and_steel') {
                // Authentic 3D Flint and Steel (着火石) in hand
                const fsGroup = new THREE.Group();
                const steelMat = new THREE.MeshLambertMaterial({ color: 0xd8d8d8 });
                const flintMat = new THREE.MeshLambertMaterial({ color: 0x2a2a2e });
                const strikerTop = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.05, 0.05), steelMat);
                strikerTop.position.set(-0.02, 0.28, 0);
                const strikerSide = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.16, 0.05), steelMat);
                strikerSide.position.set(-0.07, 0.20, 0);
                const flintPiece = new THREE.Mesh(new THREE.BoxGeometry(0.10, 0.12, 0.06), flintMat);
                flintPiece.position.set(0.05, 0.18, 0);
                fsGroup.add(strikerTop, strikerSide, flintPiece);
                fsGroup.rotation.set(0.3, 0.2, -0.1);
                armRig.add(fsGroup);
            } else if (itemKey === 'bow') {
                // Authentic 3D Bow & String in hand
                const bowGroup = new THREE.Group();
                const woodMat = new THREE.MeshLambertMaterial({ color: 0x7a4e25 });
                const stringMat = new THREE.MeshBasicMaterial({ color: 0xeeeeee });
                const limbMid = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.26, 0.05), woodMat);
                limbMid.position.set(0, 0.30, -0.06);
                const limbTop = new THREE.Mesh(new THREE.BoxGeometry(0.045, 0.20, 0.045), woodMat);
                limbTop.position.set(0, 0.48, 0.02);
                limbTop.rotation.x = -0.45;
                const limbBot = new THREE.Mesh(new THREE.BoxGeometry(0.045, 0.20, 0.045), woodMat);
                limbBot.position.set(0, 0.12, 0.02);
                limbBot.rotation.x = 0.45;
                const bowString = new THREE.Mesh(new THREE.BoxGeometry(0.015, 0.52, 0.015), stringMat);
                bowString.position.set(0, 0.30, 0.09);
                bowGroup.add(limbMid, limbTop, limbBot, bowString);
                bowGroup.rotation.set(0.2, 0.1, 0);
                armRig.add(bowGroup);
            } else if (itemKey?.includes('bucket')) {
                // 3D Iron Bucket (Empty, Water, or Lava)
                const bucketGroup = new THREE.Group();
                const ironMat = new THREE.MeshLambertMaterial({ color: 0xc8ccd0 });
                const body = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.20, 0.18), ironMat);
                body.position.set(0, 0.22, 0);
                bucketGroup.add(body);
                if (itemKey === 'water_bucket' || itemKey === 'lava_bucket') {
                    const liquidColor = (itemKey === 'water_bucket') ? 0x2268e8 : 0xff5500;
                    const liquid = new THREE.Mesh(
                        new THREE.BoxGeometry(0.15, 0.04, 0.15),
                        new THREE.MeshBasicMaterial({ color: liquidColor })
                    );
                    liquid.position.set(0, 0.31, 0);
                    bucketGroup.add(liquid);
                }
                armRig.add(bucketGroup);
            } else if (itemDef?.category === 'combat' || itemKey?.includes('sword') || itemKey?.includes('blade')) {
                // Authentic Minecraft 3D Sword (Handle, Crossguard, Blade)
                const swordGroup = new THREE.Group();
                const stickMat = new THREE.MeshLambertMaterial({ color: 0x5a3d28 });

                // Pommel
                const pommel = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.04, 0.06), stickMat);
                pommel.position.set(0, 0.02, 0);
                swordGroup.add(pommel);

                // Handle (grip)
                const handle = new THREE.Mesh(new THREE.BoxGeometry(0.045, 0.18, 0.045), stickMat);
                handle.position.set(0, 0.12, 0);
                swordGroup.add(handle);

                // Crossguard
                const guardMat = new THREE.MeshLambertMaterial({ color: 0x3e2815 });
                const guard = new THREE.Mesh(new THREE.BoxGeometry(0.24, 0.05, 0.06), guardMat);
                guard.position.set(0, 0.22, 0);
                swordGroup.add(guard);

                // Blade
                let bladeColor = 0x8a6035; // Wood default
                if (itemKey?.includes('stone')) bladeColor = 0x7a7a7a;
                else if (itemKey?.includes('iron')) bladeColor = 0xe0e0e0;
                else if (itemKey?.includes('gold')) bladeColor = 0xffd700;
                else if (itemKey?.includes('diamond')) bladeColor = 0x4dedf0;
                else if (itemKey?.includes('netherite')) bladeColor = 0x483c42;
                else if (itemKey?.includes('astral')) bladeColor = 0xd044ff; // Glowing Astral

                const bladeMat = new THREE.MeshLambertMaterial({ color: bladeColor });
                const blade = new THREE.Mesh(new THREE.BoxGeometry(0.09, 0.60, 0.035), bladeMat);
                blade.position.set(0, 0.53, 0);
                swordGroup.add(blade);

                // Angle sword naturally forward from hand
                swordGroup.rotation.set(0.65, 0.1, -0.2);
                swordGroup.position.set(0, 0.06, 0);
                armRig.add(swordGroup);
            } else if (itemDef?.category === 'tools') {
                // Tools (Pickaxe, Axe, Shovel, Shears, Spyglass, Fishing Rod)
                const toolGroup = new THREE.Group();
                const stickMat = new THREE.MeshLambertMaterial({ color: 0x6b4423 });
                const handle = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.50, 0.05), stickMat);
                handle.position.set(0, 0.25, 0);
                toolGroup.add(handle);

                let headColor = 0x888888;
                if (itemKey?.includes('wood')) headColor = 0x8a6035;
                else if (itemKey?.includes('iron') || itemKey === 'shears') headColor = 0xd8d8d8;
                else if (itemKey?.includes('gold') || itemKey === 'spyglass') headColor = 0xffb833;
                else if (itemKey?.includes('diamond') || itemKey?.includes('laser')) headColor = 0x44eeff;
                else if (itemKey?.includes('netherite')) headColor = 0x483c42;

                const headMat = new THREE.MeshLambertMaterial({ color: headColor });
                if (itemKey?.includes('pickaxe') || itemKey?.includes('drill')) {
                    const pickHead = new THREE.Mesh(new THREE.BoxGeometry(0.38, 0.08, 0.06), headMat);
                    pickHead.position.set(0, 0.48, 0);
                    toolGroup.add(pickHead);
                } else if (itemKey?.includes('axe')) {
                    const axeHead = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.18, 0.06), headMat);
                    axeHead.position.set(0.08, 0.44, 0);
                    toolGroup.add(axeHead);
                } else {
                    const shovelHead = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.22, 0.03), headMat);
                    shovelHead.position.set(0, 0.46, 0);
                    toolGroup.add(shovelHead);
                }

                toolGroup.rotation.set(0.65, 0.1, -0.2);
                armRig.add(toolGroup);
            } else if (itemDef) {
                // Generic items (Food, Ender Pearl, Fire Charge, etc.)
                let itemColor = 0xffaa44;
                if (itemKey === 'ender_pearl') itemColor = 0x188f7c;
                else if (itemKey === 'fire_charge') itemColor = 0xff5500;
                else if (itemKey === 'snowball' || itemKey === 'bone_meal') itemColor = 0xf5f5f5;
                const itemIcon = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.20, 0.08), new THREE.MeshLambertMaterial({ color: itemColor }));
                itemIcon.position.set(0, 0.20, 0);
                armRig.add(itemIcon);
            }

            // Arm resting tilt
            armRig.rotation.set(0.35, -0.20, 0.15);
            this.heldItemMesh = armRig;
            this.handGroup.add(armRig);
        }

        setupInputs() {
            const dom = this.renderer.domElement;

            // Prevent browser right-click context menu from interrupting block placement or item use
            window.addEventListener('contextmenu', (e) => {
                e.preventDefault();
            });

            dom.addEventListener('click', () => {
                if (this.inventory.openMode === 'none') {
                    this.requestPointerLock();
                    this.sound.init();
                    this.sound.startAmbientBGM();
                }
            });

            document.addEventListener('pointerlockchange', () => {
                this.isPointerLocked = (document.pointerLockElement === dom);
                if (this.isPointerLocked) {
                    this.pointerLockAcquired = true;
                } else {
                    // Always clear held keys & mouse buttons when pointer lock exits so Space/WASD never get stuck!
                    this.input.keys = {};
                    this.input.mouseButtons = {};
                    this.input.spaceJustPressed = false;
                    if (this.gameStarted && this.pointerLockAcquired && this.inventory.openMode === 'none' && !this.player.isDead) {
                        this.pointerLockAcquired = false;
                        this.ui.openModal('pause');
                    }
                }
            });

            window.addEventListener('blur', () => {
                this.input.keys = {};
                this.input.mouseButtons = {};
                this.input.spaceJustPressed = false;
            });

            document.addEventListener('mousemove', (e) => {
                if (!this.isPointerLocked) return;
                const sens = 0.0022;
                this.player.yaw -= e.movementX * sens;
                this.player.pitch -= e.movementY * sens;
                const maxPitch = Math.PI / 2 - 0.01;
                this.player.pitch = Math.max(-maxPitch, Math.min(maxPitch, this.player.pitch));
            });

            window.addEventListener('keydown', (e) => {
                this.sound.init();
                if (e.code === 'Space') {
                    this.input.spaceJustPressed = true;
                }
                this.input.keys[e.code] = true;

                // Authentic Minecraft Double-Tap W or Up-Arrow to Sprint!
                if ((e.code === 'KeyW' || e.code === 'ArrowUp') && !e.repeat) {
                    const now = performance.now();
                    if (now - this.lastForwardPressTime < 320) {
                        this.player.isSprinting = true;
                    }
                    this.lastForwardPressTime = now;
                }

                // Hotbar select with 1-9
                if (e.key >= '1' && e.key <= '9') {
                    this.inventory.selectedHotbarIndex = parseInt(e.key) - 1;
                }

                // Inventory 'E' key
                if (e.code === 'KeyE') {
                    if (this.inventory.openMode === 'none') {
                        if (this.player.gameMode === 'creative') {
                            this.ui.openModal('creative');
                        } else {
                            this.ui.openModal('inventory');
                        }
                    } else {
                        this.ui.closeModal();
                    }
                }

                // Chat 'T' or '/'
                if ((e.code === 'KeyT' || e.key === '/') && this.inventory.openMode === 'none') {
                    e.preventDefault();
                    this.ui.openChat();
                    if (e.key === '/') this.ui.chatInput.value = '/';
                }

                // F3 Debug toggle
                if (e.code === 'F3') {
                    e.preventDefault();
                    this.showDebug = !this.showDebug;
                }

                // Escape key toggle pause menu
                if (e.code === 'Escape') {
                    if (this.inventory.openMode !== 'none') {
                        if (this.gameStarted) {
                            this.ui.closeModal();
                        }
                    } else if (this.gameStarted && !this.player.isDead) {
                        this.ui.openModal('pause');
                    }
                }
            });

            window.addEventListener('keyup', (e) => {
                this.input.keys[e.code] = false;
                // Stop sprinting when releasing forward movement key
                if (e.code === 'KeyW' || e.code === 'ArrowUp') {
                    this.player.isSprinting = false;
                }
            });

            // Mouse wheel for hotbar
            window.addEventListener('wheel', (e) => {
                if (this.isPointerLocked) {
                    if (e.deltaY > 0) {
                        this.inventory.selectedHotbarIndex = (this.inventory.selectedHotbarIndex + 1) % 9;
                    } else {
                        this.inventory.selectedHotbarIndex = (this.inventory.selectedHotbarIndex + 8) % 9;
                    }
                }
            });

            // Mouse Click (Mining, Placing & Double-click sprint toggle)
            window.addEventListener('mousedown', (e) => {
                if (!this.isPointerLocked) return;
                this.input.mouseButtons[e.button] = true;

                if (e.button === 0) {
                    // Double-click mouse to toggle sprint
                    const now = performance.now();
                    if (now - this.lastClickTime < 300) {
                        this.player.isSprinting = !this.player.isSprinting;
                    }
                    this.lastClickTime = now;

                    // Left click: Attack mob or Mine
                    this.player.swingHand();
                    this.handleLeftClick();
                } else if (e.button === 2) {
                    // Right click: Interact / Place block / Custom ability
                    this.handleRightClick();
                }
            });

            window.addEventListener('mouseup', (e) => {
                this.input.mouseButtons[e.button] = false;
                if (e.button === 0) {
                    this.player.miningProgress = 0;
                }
            });
        }

        requestPointerLock() {
            if (this.sound) {
                this.sound.init();
                this.sound.startAmbientBGM();
            }
            this.renderer.domElement.requestPointerLock();
        }

        handleLeftClick() {
            // Check mob hit
            const ray = this.player.raycast(4.5);
            const cameraDir = new THREE.Vector3();
            this.camera.getWorldDirection(cameraDir);
            const origin = new THREE.Vector3(this.player.x, this.player.y + this.player.eyeHeight, this.player.z);

            const hitMob = this.mobManager.checkMobHit(origin.clone().addScaledVector(cameraDir, 2.0), 1.5);
            if (hitMob) {
                const heldItem = this.inventory.getSelectedItem();
                const itemDef = window.ITEMS[heldItem?.item];
                const damage = itemDef?.damage || 1;
                hitMob.takeDamage(damage);
                this.sound.playHit();
                this.itemManager.spawnBlockParticles(hitMob.x, hitMob.y + 1, hitMob.z, 0xff2222, 6);
                return;
            }

            if (ray) {
                const bId = ray.blockId;
                const def = window.BLOCK_BY_ID[bId];
                const B = window.BLOCKS;

                // Instant break in Creative OR for 0-hardness blocks (Fire, Torch, Flowers, Sapling, TNT punch if creative)
                if (this.player.gameMode === 'creative' || (def && def.hardness === 0.0)) {
                    this.world.setBlock(ray.x, ray.y, ray.z, B.AIR.id);
                    if (B.FIRE && bId === B.FIRE.id) {
                        this.sound.playFuse();
                        this.itemManager.spawnBlockParticles(ray.x + 0.5, ray.y + 0.5, ray.z + 0.5, 0x555555, 6);
                    } else {
                        this.sound.playBreak(def?.sound || 'stone');
                        this.itemManager.spawnBlockParticles(ray.x + 0.5, ray.y + 0.5, ray.z + 0.5, 0xaaaaaa, 8);
                        if (this.player.gameMode !== 'creative' && def?.drop) {
                            this.itemManager.spawnDroppedItem(ray.x + 0.5, ray.y + 0.5, ray.z + 0.5, def.drop);
                        }
                    }
                    this.world.applyGravityAbove(ray.x, ray.y, ray.z);
                }
            }
        }

        handleRightClick() {
            const heldItem = this.inventory.getSelectedItem();
            const itemKey = heldItem ? heldItem.item : null;
            const itemDef = itemKey ? window.ITEMS[itemKey] : null;
            const ray = this.player.raycast(5.5);
            const B = window.BLOCKS;
            const isSneaking = !!(this.input.keys['ShiftLeft'] || this.input.keys['ShiftRight']);

            const dir = new THREE.Vector3();
            this.camera.getWorldDirection(dir);
            const eyeOrigin = new THREE.Vector3(this.player.x, this.player.y + this.player.eyeHeight, this.player.z);

            // ★ 1. Flint and Steel (火打石と打ち金 / 着火石) & Fire Charge (ファイヤーチャージ)
            if (itemKey === 'flint_and_steel' || itemKey === 'fire_charge') {
                this.player.swingHand();
                if (this.sound.playFlintAndSteel) this.sound.playFlintAndSteel();

                if (ray) {
                    const bId = ray.blockId;
                    // 1a. Ignite TNT or Cluster TNT!
                    if (bId === B.TNT.id || bId === B.CLUSTER_TNT.id) {
                        this.itemManager.igniteTnt(ray.x, ray.y, ray.z, bId === B.CLUSTER_TNT.id);
                        if (itemKey === 'fire_charge' && this.player.gameMode !== 'creative') {
                            this.inventory.consumeSelectedItem(1);
                        }
                        return;
                    }
                    // 1b. Ignite Obsidian -> Activate Nether Portal!
                    if (bId === B.OBSIDIAN.id && B.NETHER_PORTAL) {
                        const px = ray.x + ray.normal[0];
                        const py = ray.y + ray.normal[1];
                        const pz = ray.z + ray.normal[2];
                        for (let dy = 0; dy < 3; dy++) {
                            for (let dx = 0; dx < 2; dx++) {
                                if (this.world.getBlock(px + dx, py + dy, pz) === B.AIR.id) {
                                    this.world.setBlock(px + dx, py + dy, pz, B.NETHER_PORTAL.id);
                                }
                            }
                        }
                        this.sound.playWarp();
                        this.itemManager.spawnBlockParticles(px + 0.5, py + 1.0, pz + 0.5, 0xb533ff, 24);
                        this.ui.addChatMessage('🔥 黒曜石に着火し、ネザーポータルが起動しました！', '#d066ff');
                        if (itemKey === 'fire_charge' && this.player.gameMode !== 'creative') {
                            this.inventory.consumeSelectedItem(1);
                        }
                        return;
                    }
                    // 1c. Ignite Fire on the clicked block face!
                    if (B.FIRE) {
                        const fx = ray.x + ray.normal[0];
                        const fy = ray.y + ray.normal[1];
                        const fz = ray.z + ray.normal[2];
                        if (this.world.getBlock(fx, fy, fz) === B.AIR.id) {
                            this.world.setBlock(fx, fy, fz, B.FIRE.id);
                            this.itemManager.spawnBlockParticles(fx + 0.5, fy + 0.3, fz + 0.5, 0xff7711, 10);
                            if (itemKey === 'fire_charge' && this.player.gameMode !== 'creative') {
                                this.inventory.consumeSelectedItem(1);
                            }
                            return;
                        }
                    }
                } else if (itemKey === 'fire_charge') {
                    // Shoot Fireball into the air!
                    this.itemManager.shootFireball(eyeOrigin.clone().addScaledVector(dir, 0.8), dir);
                    if (this.player.gameMode !== 'creative') {
                        this.inventory.consumeSelectedItem(1);
                    }
                    return;
                }
                return;
            }

            // ★ 2. Bow & Arrow (弓矢の発射)
            if (itemKey === 'bow') {
                // In survival, check if player has arrows (or allow shooting if creative)
                let canShoot = (this.player.gameMode === 'creative');
                if (!canShoot) {
                    for (let i = 0; i < 36; i++) {
                        if (this.inventory.slots[i] && this.inventory.slots[i].item === 'arrow') {
                            this.inventory.slots[i].count--;
                            if (this.inventory.slots[i].count <= 0) this.inventory.slots[i] = null;
                            canShoot = true;
                            break;
                        }
                    }
                    // Even if out of arrows, allow shooting basic arrows so bow is always fun & usable!
                    canShoot = true;
                }
                if (canShoot) {
                    this.itemManager.shootArrow(eyeOrigin.clone().addScaledVector(dir, 0.8), dir, 1.0);
                    this.player.swingHand();
                }
                return;
            }

            // ★ 3. Ender Pearl (エンダーパール瞬間移動)
            if (itemKey === 'ender_pearl') {
                this.itemManager.throwEnderPearl(eyeOrigin.clone().addScaledVector(dir, 0.8), dir);
                this.player.swingHand();
                if (this.player.gameMode !== 'creative') {
                    this.inventory.consumeSelectedItem(1);
                }
                return;
            }

            // ★ 4. Snowball (雪玉の投擲)
            if (itemKey === 'snowball') {
                this.itemManager.throwSnowball(eyeOrigin.clone().addScaledVector(dir, 0.8), dir);
                this.player.swingHand();
                if (this.player.gameMode !== 'creative') {
                    this.inventory.consumeSelectedItem(1);
                }
                return;
            }

            // ★ 5. Buckets (空のバケツ・水バケツ・溶岩バケツ)
            if (itemKey === 'bucket') {
                const fluidHit = this.player.raycastFluid(5.0);
                if (fluidHit) {
                    this.world.setBlock(fluidHit.x, fluidHit.y, fluidHit.z, B.AIR.id);
                    const newBucket = (fluidHit.blockId === B.WATER.id) ? 'water_bucket' : 'lava_bucket';
                    if (this.player.gameMode !== 'creative') {
                        this.inventory.consumeSelectedItem(1);
                        this.inventory.addItem(newBucket, 1);
                    } else {
                        this.inventory.slots[this.inventory.selectedHotbarIndex] = { item: newBucket, count: 1 };
                    }
                    this.sound.playPop();
                    this.player.swingHand();
                    return;
                }
            } else if ((itemKey === 'water_bucket' || itemKey === 'lava_bucket') && ray) {
                const px = ray.x + ray.normal[0];
                const py = ray.y + ray.normal[1];
                const pz = ray.z + ray.normal[2];
                const fluidBlockId = (itemKey === 'water_bucket') ? B.WATER.id : B.LAVA.id;
                this.world.setBlock(px, py, pz, fluidBlockId);
                if (this.player.gameMode !== 'creative') {
                    this.inventory.slots[this.inventory.selectedHotbarIndex] = { item: 'bucket', count: 1 };
                }
                this.sound.playPlace();
                this.player.swingHand();
                return;
            }

            // ★ 6. Bone Meal (骨粉: 苗木の即座成長＆草花生成)
            if (itemKey === 'bone_meal' && ray) {
                const bId = ray.blockId;
                if (B.SAPLING && bId === B.SAPLING.id) {
                    this.world.setBlock(ray.x, ray.y, ray.z, B.AIR.id);
                    this.world.generateTree(ray.x, ray.y, ray.z);
                    this.world.updateChunksAround(ray.x, ray.z, 1);
                    this.itemManager.spawnBlockParticles(ray.x + 0.5, ray.y + 1.5, ray.z + 0.5, 0x44ff44, 20);
                    this.sound.playHeal();
                    this.player.swingHand();
                    if (this.player.gameMode !== 'creative') this.inventory.consumeSelectedItem(1);
                    return;
                } else if (bId === B.GRASS.id || bId === B.DIRT.id) {
                    this.world.setBlock(ray.x, ray.y, ray.z, B.GRASS.id);
                    for (let dx = -2; dx <= 2; dx++) {
                        for (let dz = -2; dz <= 2; dz++) {
                            const gx = ray.x + dx;
                            const gz = ray.z + dz;
                            if (this.world.getBlock(gx, ray.y, gz) === B.GRASS.id && this.world.getBlock(gx, ray.y + 1, gz) === B.AIR.id) {
                                if (Math.random() < 0.35) {
                                    const flowerId = (Math.random() < 0.5) ? B.FLOWER_RED.id : B.FLOWER_YELLOW.id;
                                    this.world.setBlock(gx, ray.y + 1, gz, flowerId);
                                }
                            }
                        }
                    }
                    this.itemManager.spawnBlockParticles(ray.x + 0.5, ray.y + 1.1, ray.z + 0.5, 0x44ff44, 15);
                    this.sound.playPop();
                    this.player.swingHand();
                    if (this.player.gameMode !== 'creative') this.inventory.consumeSelectedItem(1);
                    return;
                }
            }

            // ★ 7. Shears (ハサミ: 羊の毛刈り＆葉ブロック採取)
            if (itemKey === 'shears') {
                const hitMob = this.mobManager.checkMobHit(eyeOrigin.clone().addScaledVector(dir, 2.2), 1.8);
                if (hitMob && hitMob.type === 'sheep') {
                    const woolCount = 2 + Math.floor(Math.random() * 2);
                    this.itemManager.spawnDroppedItem(hitMob.x, hitMob.y + 0.6, hitMob.z, 'wool_white', woolCount);
                    this.itemManager.spawnBlockParticles(hitMob.x, hitMob.y + 0.6, hitMob.z, 0xffffff, 10);
                    this.sound.playPop();
                    this.player.swingHand();
                    return;
                }
                if (ray && ray.blockId === B.OAK_LEAVES.id) {
                    this.world.setBlock(ray.x, ray.y, ray.z, B.AIR.id);
                    this.itemManager.spawnDroppedItem(ray.x + 0.5, ray.y + 0.5, ray.z + 0.5, 'oak_leaves', 1);
                    this.sound.playBreak('grass');
                    this.player.swingHand();
                    return;
                }
            }

            // ★ 8. Fishing Rod, Compass, Clock, Spyglass
            if (itemKey === 'fishing_rod') {
                this.player.swingHand();
                this.sound.playBowShoot();
                const catches = ['raw_cod', 'raw_salmon', 'raw_cod', 'raw_salmon', 'golden_apple'];
                const caught = catches[Math.floor(Math.random() * catches.length)];
                this.inventory.addItem(caught, 1);
                this.sound.playPop();
                this.ui.addChatMessage(`🎣 釣り竿で「${window.ITEMS[caught]?.nameJa || caught}」を釣り上げました！`, '#66ddff');
                return;
            } else if (itemKey === 'compass') {
                const distAncient = Math.round(Math.hypot(32.5 - this.player.x, 32.5 - this.player.z));
                this.ui.addChatMessage(`🧭 コンパス: 初期スポーン地点 (8, 8) / 古代都市 (32, 32 - 距離 ${distAncient}m)`, '#55ffaa');
                return;
            } else if (itemKey === 'clock') {
                const totalHours = Math.floor(this.timeOfDay * 24);
                const mins = Math.floor((this.timeOfDay * 24 - totalHours) * 60);
                const hh = String(totalHours).padStart(2, '0');
                const mm = String(mins).padStart(2, '0');
                this.ui.addChatMessage(`🕒 時計: 現在時刻 ${hh}:${mm} (${this.timeOfDay < 0.5 ? '昼間 ☀️' : '夜間 🌙'})`, '#ffdd55');
                return;
            } else if (itemKey === 'spyglass') {
                this.player.isZooming = !this.player.isZooming;
                this.sound.playPop();
                return;
            }

            // ★ 9. Custom Item: Astral Blade (Shockwave Slash!)
            if (itemKey === 'astral_blade') {
                this.itemManager.shootAstralSlash(eyeOrigin.clone().addScaledVector(dir, 1.0), dir);
                this.player.swingHand();
                return;
            }

            // ★ 10. Custom Item: Laser Drill (Area Mine 3x3x3!)
            if (itemKey === 'laser_drill' && ray) {
                this.sound.playLaser();
                for (let dx = -1; dx <= 1; dx++) {
                    for (let dy = -1; dy <= 1; dy++) {
                        for (let dz = -1; dz <= 1; dz++) {
                            const bx = ray.x + dx;
                            const by = ray.y + dy;
                            const bz = ray.z + dz;
                            const bId = this.world.getBlock(bx, by, bz);
                            const def = window.BLOCK_BY_ID[bId];
                            if (def && def.solid && def.id !== B.BEDROCK.id) {
                                this.world.setBlock(bx, by, bz, B.AIR.id);
                                if (def.drop) {
                                    this.itemManager.spawnDroppedItem(bx + 0.5, by + 0.5, bz + 0.5, def.drop);
                                }
                            }
                        }
                    }
                }
                this.itemManager.spawnBlockParticles(ray.x + 0.5, ray.y + 0.5, ray.z + 0.5, 0x44ddff, 16);
                return;
            }

            // ★ 11. Eat Food
            if (itemDef?.category === 'food' && (this.player.food < this.player.maxFood || itemDef.heal || this.player.gameMode === 'creative')) {
                this.player.food = Math.min(this.player.maxFood, this.player.food + (itemDef.foodRestore || 4));
                if (itemDef.heal) this.player.heal(itemDef.heal);
                if (this.player.gameMode !== 'creative') {
                    this.inventory.consumeSelectedItem(1);
                }
                this.sound.playPop();
                this.player.swingHand();
                return;
            }

            // ★ 12. Block Interaction & Block Placement
            if (ray) {
                const bId = ray.blockId;

                // Functional blocks (unless sneaking with a block in hand to build onto them)
                if (!isSneaking) {
                    if (bId === B.CRAFTING_TABLE.id) {
                        this.ui.openModal('crafting');
                        return;
                    } else if (bId === B.FURNACE.id) {
                        this.ui.openModal('furnace');
                        return;
                    } else if (bId === B.CHEST.id) {
                        this.ui.openModal('chest');
                        return;
                    } else if (B.BED && bId === B.BED.id) {
                        this.timeOfDay = 0.22; // Bright morning!
                        this.player.heal(20);
                        this.sound.playHeal();
                        this.ui.addChatMessage('🛏️ ベッドで眠り、体力が全回復して爽やかな朝を迎えました！', '#ffdd55');
                        return;
                    } else if (bId === B.WAYGATE.id) {
                        this.teleportToNextWaygate(ray.x, ray.y, ray.z);
                        return;
                    } else if ((bId === B.TNT.id || bId === B.CLUSTER_TNT.id) && itemKey !== 'tnt' && itemKey !== 'cluster_tnt') {
                        // Right-clicking TNT ignites it (and holding TNT allows stacking more TNT blocks!)
                        if (this.sound.playFlintAndSteel) this.sound.playFlintAndSteel();
                        this.itemManager.igniteTnt(ray.x, ray.y, ray.z, bId === B.CLUSTER_TNT.id);
                        this.player.swingHand();
                        return;
                    }
                }

                // ★ 13. Place Block in World
                if (itemDef && itemDef.blockId) {
                    const px = ray.x + ray.normal[0];
                    const py = ray.y + ray.normal[1];
                    const pz = ray.z + ray.normal[2];

                    const targetBlockDef = window.BLOCK_BY_ID[itemDef.blockId];
                    const placeBox = new AABB(px, py, pz, px + 1, py + 1, pz + 1);
                    const playerBox = new AABB(
                        this.player.x - 0.26, this.player.y + 0.05, this.player.z - 0.26,
                        this.player.x + 0.26, this.player.y + 1.72, this.player.z + 0.26
                    );

                    if (!placeBox.intersects(playerBox) || !targetBlockDef?.solid) {
                        this.world.setBlock(px, py, pz, itemDef.blockId);
                        this.sound.playPlace();
                        this.player.swingHand();
                        if (this.player.gameMode !== 'creative') {
                            this.inventory.consumeSelectedItem(1);
                        }
                        // If Sand or Gravel placed in mid-air, apply gravity
                        if (itemDef.blockId === B.SAND.id || itemDef.blockId === B.GRAVEL.id) {
                            this.world.applyGravityAbove(px, py - 1, pz);
                        }
                    }
                }
            }
        }

        teleportToNextWaygate(curX, curY, curZ) {
            const gates = this.world.teleportWaygates;
            if (gates.length <= 1) {
                this.ui.addChatMessage('テレポート先となる別のウェイゲートがありません。', '#ff8888');
                return;
            }
            // Find next gate in list
            let nextIndex = 0;
            for (let i = 0; i < gates.length; i++) {
                if (gates[i].x === curX && gates[i].y === curY && gates[i].z === curZ) {
                    nextIndex = (i + 1) % gates.length;
                    break;
                }
            }
            const target = gates[nextIndex];
            this.player.x = target.x + 0.5;
            this.player.y = target.y + 1.2;
            this.player.z = target.z + 0.5;
            this.sound.playWarp();
            this.itemManager.spawnBlockParticles(this.player.x, this.player.y, this.player.z, 0xee22ff, 20);
            this.ui.addChatMessage(`ウェイゲートへテレポートしました！ (${target.x}, ${target.y}, ${target.z})`, '#bb55ff');
        }

        handleMiningTick(dt) {
            if (this.player.gameMode === 'creative') {
                this.crackBox.visible = false;
                return;
            }

            if (this.input.mouseButtons[0]) {
                if (!this.player.isSwinging) {
                    this.player.swingHand();
                }
                const ray = this.player.raycast(4.5);
                if (ray) {
                    const bId = ray.blockId;
                    const def = window.BLOCK_BY_ID[bId];
                    if (def && def.hardness !== Infinity) {
                        const heldItem = this.inventory.getSelectedItem();
                        const toolDef = window.ITEMS[heldItem?.item];

                        let speed = 1.0;
                        if (toolDef && toolDef.toolType === def.tool) {
                            speed = toolDef.speed || 2.0;
                        }

                        this.player.miningProgress += (dt * speed) / Math.max(0.15, def.hardness || 1.0);

                        // Update Crack Overlay Box (0 to 9 stages)
                        const stage = Math.min(9, Math.floor(this.player.miningProgress * 10));
                        this.crackBox.visible = true;
                        this.crackBox.position.set(ray.x + 0.5, ray.y + 0.5, ray.z + 0.5);
                        this.atlas.applyCrackUVs(this.crackBox.geometry, stage);

                        // Digging sound & particles
                        this.player.breakSoundTimer = (this.player.breakSoundTimer || 0) + dt;
                        if (this.player.breakSoundTimer > 0.22) {
                            this.sound.playDig(def.sound || 'stone');
                            this.itemManager.spawnBlockParticles(ray.x + 0.5, ray.y + 0.5, ray.z + 0.5, 0x888888, 2);
                            this.player.breakSoundTimer = 0;
                        }

                        if (this.player.miningProgress >= 1.0) {
                            // Break block!
                            this.world.setBlock(ray.x, ray.y, ray.z, window.BLOCKS.AIR.id);
                            this.sound.playBreak(def.sound || 'stone');
                            this.player.miningProgress = 0;
                            this.crackBox.visible = false;

                            // Drop item (Gravel has 35% chance to drop Flint for crafting Flint & Steel!)
                            if (bId === window.BLOCKS.GRAVEL.id && Math.random() < 0.35) {
                                this.itemManager.spawnDroppedItem(ray.x + 0.5, ray.y + 0.5, ray.z + 0.5, 'flint');
                            } else if (def.drop) {
                                this.itemManager.spawnDroppedItem(ray.x + 0.5, ray.y + 0.5, ray.z + 0.5, def.drop);
                            }
                            this.itemManager.spawnBlockParticles(ray.x + 0.5, ray.y + 0.5, ray.z + 0.5, 0x888888, 8);
                            // Safe Sand/Gravel gravity physics
                            this.world.applyGravityAbove(ray.x, ray.y, ray.z);
                        }
                        return;
                    }
                }
            }
            this.player.miningProgress = 0;
            this.crackBox.visible = false;
        }

        // UI Slot Interactions
        handleSlotClick(type, index) {
            try {
                let targetArr = null;

                if (type === 'player') targetArr = this.inventory.slots;
                else if (type === 'craft2x2') targetArr = this.inventory.craft2x2;
                else if (type === 'craft3x3') targetArr = this.inventory.craft3x3;
                else if (type === 'chest') targetArr = this.inventory.chestSlots;

                if (!targetArr) return;

                const cur = this.inventory.cursorItem;
                const slot = targetArr[index];

                if (!cur && slot) {
                    this.inventory.cursorItem = slot;
                    targetArr[index] = null;
                    this.sound.playPop();
                } else if (cur && !slot) {
                    targetArr[index] = cur;
                    this.inventory.cursorItem = null;
                    this.sound.playPlace();
                } else if (cur && slot) {
                    if (cur.item === slot.item) {
                        const max = window.ITEMS[cur.item]?.maxStack || 64;
                        const space = max - slot.count;
                        const add = Math.min(space, cur.count);
                        slot.count += add;
                        cur.count -= add;
                        if (cur.count <= 0) this.inventory.cursorItem = null;
                    } else {
                        targetArr[index] = cur;
                        this.inventory.cursorItem = slot;
                    }
                    this.sound.playPlace();
                }

                if (type.startsWith('craft')) {
                    this.inventory.updateCraftResult(type === 'craft3x3');
                }
                this.refreshModalUI();
            } catch (err) {
                console.warn('Slot click safety guard:', err);
            }
        }

        handleCraftResultClick(is3x3 = false) {
            try {
                if (!this.inventory.craftResult) return;
                const res = this.inventory.craftResult;

                if (!this.inventory.cursorItem) {
                    this.inventory.cursorItem = { item: res.item, count: res.count };
                    this.inventory.takeCraftResult(is3x3);
                    this.sound.playPop();
                } else if (this.inventory.cursorItem.item === res.item) {
                    this.inventory.cursorItem.count += res.count;
                    this.inventory.takeCraftResult(is3x3);
                    this.sound.playPop();
                }
                this.refreshModalUI();
            } catch (err) {
                console.warn('Craft result safety guard:', err);
            }
        }

        handleFurnaceClick(slotType) {
            try {
                const f = this.inventory.furnace;
                const cur = this.inventory.cursorItem;
                const slot = f[slotType];

                if (!cur && slot) {
                    this.inventory.cursorItem = slot;
                    f[slotType] = null;
                    this.sound.playPop();
                } else if (cur && !slot) {
                    if (slotType !== 'output') {
                        f[slotType] = cur;
                        this.inventory.cursorItem = null;
                        this.sound.playPlace();
                    }
                } else if (cur && slot) {
                    if (cur.item === slot.item && slotType !== 'output') {
                        const max = window.ITEMS[cur.item]?.maxStack || 64;
                        const space = max - slot.count;
                        const add = Math.min(space, cur.count);
                        slot.count += add;
                        cur.count -= add;
                        if (cur.count <= 0) this.inventory.cursorItem = null;
                        this.sound.playPlace();
                    }
                }
                this.refreshModalUI();
            } catch (err) {
                console.warn('Furnace safety guard:', err);
            }
        }

        pickCreativeItem(itemKey) {
            const def = window.ITEMS[itemKey];
            const maxStack = def?.maxStack || 64;
            const added = this.inventory.addItem(itemKey, maxStack);
            if (!added) {
                this.inventory.slots[this.inventory.selectedHotbarIndex] = { item: itemKey, count: maxStack };
            }
            for (let i = 0; i < 9; i++) {
                if (this.inventory.slots[i] && this.inventory.slots[i].item === itemKey) {
                    this.inventory.selectedHotbarIndex = i;
                    break;
                }
            }
            this.sound.playPop();
            this.ui.renderHUD();
        }

        refreshModalUI() {
            const mode = this.inventory.openMode;
            if (mode === 'inventory') this.ui.renderInventoryModal();
            else if (mode === 'crafting') this.ui.renderCraftingModal();
            else if (mode === 'furnace') this.ui.renderFurnaceModal();
            else if (mode === 'chest') this.ui.renderChestModal();
            this.ui.renderHUD();
        }

        toggleGameMode() {
            const newMode = (this.player.gameMode === 'creative') ? 'survival' : 'creative';
            this.player.setGameMode(newMode);
            this.input.keys = {};
            this.input.mouseButtons = {};
            this.input.spaceJustPressed = false;
            const toggleBtn = document.getElementById('pause-mode-btn');
            if (toggleBtn) {
                toggleBtn.textContent = `ゲームモード切替 (現在: ${newMode === 'creative' ? 'クリエイティブ' : 'サバイバル'})`;
            }
            this.ui.renderHUD();
            this.ui.addChatMessage(`ゲームモードを「${newMode === 'creative' ? 'クリエイティブ' : 'サバイバル'}」に切り替えました。`, '#55ff55');
            return newMode;
        }

        teleportToAncientCity() {
            this.world.updateChunksAround(32, 32, 3);
            this.player.x = 32.5;
            this.player.y = 7.2;
            this.player.z = 22.5; // Facing the giant central Reinforced Deepslate Portal at Z=32
            this.player.yaw = Math.PI;
            this.player.pitch = 0.05;
            this.player.velocity.set(0, 0, 0);
            this.player.fallDistance = 0;
            this.input.keys = {};
            if (this.mobManager && this.mobManager.spawnWardenIfNeeded) {
                this.mobManager.spawnWardenIfNeeded(32.5, 7.0, 32.5);
            }
            this.sound.playWarp();
            this.ui.closeModal();
            this.ui.addChatMessage('🏛️ ディープダーク「古代都市 (Ancient City)」の祭壇前へ移動しました！', '#44eeff');
        }

        respawnPlayer() {
            this.player.isDead = false;
            this.player.health = 20;
            this.player.food = 20;
            this.player.x = 8.5;
            this.player.z = 8.5;
            this.world.updateChunksAround(this.player.x, this.player.z, 2);
            const surfaceY = this.world.getHighestSolidY(Math.floor(this.player.x), Math.floor(this.player.z));
            this.player.y = surfaceY + 1.8;
            this.player.velocity.set(0, 0, 0);
            this.player.fallDistance = 0;
            this.ui.closeModal();
            this.requestPointerLock();
        }

        updateEnvironment(dt) {
            // Day/Night Cycle
            this.timeOfDay = (this.timeOfDay + this.daySpeed * dt) % 1.0;

            const sunAngle = this.timeOfDay * Math.PI * 2;
            const sunDistance = 200;

            const sx = Math.cos(sunAngle) * sunDistance;
            const sy = Math.sin(sunAngle) * sunDistance;

            this.sunMesh.position.set(this.player.x + sx, this.player.y + sy, this.player.z);
            this.sunMesh.lookAt(this.player.x, this.player.y, this.player.z);

            this.moonMesh.position.set(this.player.x - sx, this.player.y - sy, this.player.z);
            this.moonMesh.lookAt(this.player.x, this.player.y, this.player.z);

            this.sunLight.position.set(sx, sy, 0);

            // Drifting Clouds - Follow player infinite position
            this.cloudsGroup.position.x = this.player.x;
            this.cloudsGroup.position.z = (this.cloudsGroup.position.z + dt * 1.5);
            if (Math.abs(this.cloudsGroup.position.z - this.player.z) > 120) {
                this.cloudsGroup.position.z = this.player.z;
            }

            // Sky and Fog Colors
            let skyColor = new THREE.Color(0x6eb5ff); // day blue
            if (sy < 0) {
                // Night (Clear Moonlit Night - terrain, trees and blocks remain clearly visible!)
                skyColor.setHex(0x101830);
                this.ambientLight.color.setHex(0x99aacc);
                this.ambientLight.intensity = 0.42;
                this.sunLight.color.setHex(0x6080b0);
                this.sunLight.intensity = 0.35;
            } else if (sy < 45) {
                // Sunset / Sunrise
                skyColor.setHex(0xe88245);
                this.ambientLight.color.setHex(0xffffff);
                this.ambientLight.intensity = 0.52;
                this.sunLight.color.setHex(0xffaa66);
                this.sunLight.intensity = 0.75;
            } else {
                // Day (Bright, Sunny & Clear Morning Sun)
                skyColor.setHex(0x6eb5ff);
                this.ambientLight.color.setHex(0xffffff);
                this.ambientLight.intensity = 0.68;
                this.sunLight.color.setHex(0xfffae8);
                this.sunLight.intensity = 1.15;
            }

            // Underwater or Deep Dark (Ancient City) Atmospheric Effects
            if (this.player.headInWater) {
                const waterColor = new THREE.Color(0x15457a);
                this.scene.background = waterColor;
                this.scene.fog.color = waterColor;
                this.scene.fog.density = 0.055;
                this.ambientLight.intensity = 0.45;
            } else if (this.player.y < 16.0) {
                // Deep Dark / Ancient City Atmosphere (Mystical Soul-Cyan & Dark Slate)
                const deepDarkColor = new THREE.Color(0x06121c);
                this.scene.background = deepDarkColor;
                this.scene.fog.color = deepDarkColor;
                this.scene.fog.density = 0.022;
                this.ambientLight.color.setHex(0x75c8e8);
                this.ambientLight.intensity = 0.55;
                this.sunLight.color.setHex(0x44bbee);
                this.sunLight.intensity = 0.45;
            } else {
                this.scene.fog.density = 0.012;
                this.scene.background = skyColor;
                this.scene.fog.color = skyColor;
            }

            // Highlight target block box
            const ray = this.player.raycast(5.0);
            if (ray) {
                this.highlightBox.visible = true;
                this.highlightBox.position.set(ray.x + 0.5, ray.y + 0.5, ray.z + 0.5);
            } else {
                this.highlightBox.visible = false;
            }
        }

        animate() {
            requestAnimationFrame(() => this.animate());

            try {
                const now = performance.now();
                const dt = Math.min((now - this.lastTime) / 1000, 0.1);
                this.lastTime = now;

                // FPS Counter
                this.fpsFrames++;
                this.fpsTime += dt;
                if (this.fpsTime >= 1.0) {
                    this.currentFPS = Math.round(this.fpsFrames / this.fpsTime);
                    this.fpsFrames = 0;
                    this.fpsTime = 0;
                }

                const heldItem = this.inventory.getSelectedItem();
                this.updateHandMesh(heldItem?.item);

                if (this.inventory.openMode === 'none') {
                    this.player.update(dt, this.input, heldItem);
                    this.handleMiningTick(dt);
                    this.itemManager.update(dt, this.player, this.inventory, this.mobManager);
                    this.mobManager.update(dt, this.player, this.timeOfDay);
                    this.inventory.updateFurnace(dt);
                    this.updateEnvironment(dt);

                    // Authentic Hand Bobbing & Swinging Animation
                    const isMoving = (this.input.keys['KeyW'] || this.input.keys['KeyS'] || this.input.keys['KeyA'] || this.input.keys['KeyD']) && this.player.onGround;
                    if (isMoving) {
                        this.walkBobTimer = (this.walkBobTimer || 0) + dt * 11;
                    } else {
                        this.walkBobTimer = (this.walkBobTimer || 0) * 0.9;
                    }
                    const bobX = Math.cos(this.walkBobTimer || 0) * 0.025;
                    const bobY = Math.abs(Math.sin(this.walkBobTimer || 0)) * 0.025;

                    // Attack / Mining swing (Authentic Minecraft Downward Chop & Inward Slash)
                    const isSwinging = this.player.isSwinging;
                    const swingProgress = isSwinging ? (this.player.handSwing / Math.PI) : 0;

                    // Minecraft authentic swing dynamics:
                    // swingArc: smooth arc for translation and horizontal sweep
                    // swingChop: snappy sqrt curve for fast, powerful downward strike
                    const swingArc = Math.sin(swingProgress * Math.PI);
                    const swingChop = Math.sin(Math.sqrt(swingProgress) * Math.PI);

                    const basePosX = 0.36;
                    const basePosY = -0.32;
                    const basePosZ = -0.48;

                    // Positive rotX = chops downward towards crosshair
                    const swingRotX = swingChop * 0.95;
                    // Negative rotY = sweeps inward across screen from right
                    const swingRotY = -swingArc * 0.65;
                    // Blade roll
                    const swingRotZ = swingArc * 0.35;

                    this.handGroup.position.set(
                        basePosX + bobX - (swingArc * 0.14),
                        basePosY - bobY - (swingChop * 0.12),
                        basePosZ + (swingChop * 0.08) - (swingArc * 0.14)
                    );
                    this.handGroup.rotation.set(swingRotX, swingRotY, swingRotZ);

                    // Infinite World chunk streaming & auto unloading
                    this.world.updateChunksAround(this.player.x, this.player.z, 3, 5);
                }

                // Reset one-shot input flags
                this.input.spaceJustPressed = false;

                this.ui.renderHUD();
                this.renderer.render(this.scene, this.camera);
            } catch (frameError) {
                console.warn('Frame render safety guard caught exception:', frameError);
            }
        }
    }

    function launchGame() {
        if (!window.game) {
            try {
                window.game = new Game();
                console.log("NovaCraft Game initialized successfully.");
                if (window.pendingMode && window.game.ui) {
                    console.log("Executing pending mode:", window.pendingMode);
                    window.game.ui.selectGameMode(window.pendingMode);
                    window.pendingMode = null;
                }
            } catch (err) {
                console.error("Critical error during NovaCraft Game initialization:", err);
            }
        }
    }

    if (document.readyState === 'loading') {
        window.addEventListener('DOMContentLoaded', launchGame);
    } else {
        launchGame();
    }

    global.Game = Game;
})(window);
